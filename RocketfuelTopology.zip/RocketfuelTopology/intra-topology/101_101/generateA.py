import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import scipy as sp

f1=open("lafirstcity")
f2=open("lasecondcity")
f3=open("latency")

records1=[]
records2=[]
records3=[]
for line in f1.readlines():
    records1.append(line.strip())
for line in f2:
    records2.append(line.strip())
for line in f3:
    records3.append(line.strip())

n=len(records1)
same_line=[]
for i in range(0,n):
    for j in range (i,n):
        if i!=j and records3[i]==records3[j]:
            if records1[i]==records2[j]:
                same_line.append(j)
same_line.sort()
for i in range(0,len(same_line)):
    records3.pop(same_line[i]-i)
    records2.pop(same_line[i]-i)
    records1.pop(same_line[i]-i)


allcityname = records1 + records2
myset=set(allcityname)
allcityname=list(myset)
dictcity_num=dict(zip(allcityname,range(1,len(allcityname)+1)))

records1_num=[dictcity_num[x] for x in records1]
records2_num=[dictcity_num[x] for x in records2]
records3=map(eval,records3)

#creating the local network
edges=zip(records1_num,records2_num,records3)
G=nx.Graph()
G.add_weighted_edges_from(edges)
nx.draw_networkx(G)
plt.savefig("figure.png")
#plt.show()

#print (G.adj)
#print G['1:Honolulu, HI']['1:Los Angeles, CA']['weight']

#generate adjacency matrix,if edge_attr=weight, then generate weight matrix
#attr_matrix()
A=nx.adjacency_matrix(G,nodelist=None,weight=None)
f=open('A','w')
print >>f,A
f.close()

#dijkstra_path() and dijkstra_path_length
#print nx.dijkstra_path_length(G,1,30)

f1.close()
f2.close()
f3.close()